<?php $this->load->library('user_agent');
if ($this->agent->is_mobile()):?>
	 <?php if ($this->auth_check): ?>
  <div class="mb-footer-navbar signed-in" style="background-color: #FFFFFF;
    box-shadow: 0 -4px 20px 0 rgba(0,0,0,0.2);
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 400;
}">
<ul>
<li class="active">
<a href="<?php echo lang_base_url(); ?>">
<img src="<?php echo lang_base_url(); ?>/assets/img/home.svg" alt="Ic home">
<p class="icon-title">Home</p>
</a>
</li>
<li class="">
<a href="<?php echo lang_base_url(); ?>favorites/<?php echo $this->auth_user->slug; ?>">
<img src="<?php echo lang_base_url(); ?>/assets/img/favorit.svg" alt="Ic favorites off">
<p class="icon-title">Favorit</p>
</a>
</li>
<li class="pasang-iklan-container">
<a href="<?php echo lang_base_url(); ?>sell-now">
<div class="pasang-iklan-btn">
<span class="plus-icon"></span>

</div>
</a>
</li>
<li class="">
<a href="<?php echo lang_base_url(); ?>messages" id="chat_dot_block">
<div class="counter-container chat-icon">
<img src="<?php echo lang_base_url(); ?>/assets/img/chat.svg" alt="Ic chat off">

</div>
<p class="icon-title">Chat</p>
</a>
</li>
<li class="">
<a href="<?php echo lang_base_url(); ?>profile/<?php echo $this->auth_user->slug; ?>" >
<img src="<?php echo get_user_avatar($this->auth_user); ?>" alt="Ic profile off">
<p class="icon-title">Profil</p>
</a>
</li>
</ul>
</div>
  <?php else: ?>
  <div class="mb-footer-navbar not-signed-in" style="background-color: #FFFFFF;
    box-shadow: 0 -4px 20px 0 rgba(0,0,0,0.2);
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 400;
}">
<ul>
<li class="active">
<a href="<?php echo lang_base_url(); ?>">
<img src="<?php echo lang_base_url(); ?>/assets/img/home.svg" alt="Ic home">
<p class="icon-title">Home</p>
</a>
</li>
<li class="pasang-iklan-container">
<a href="javascript:void(0)" data-toggle="modal" data-target="#loginModal" id="signinModalBtn">
<div class="pasang-iklan-btn">
<span class="plus-icon"></span>
<span class="button-text">Jual produk</span>
</div>
</a>
</li>
<li>
<a href="javascript:void(0)" data-toggle="modal" data-target="#loginModal" id="signinModalBtn">
<img src="<?php echo lang_base_url(); ?>/assets/img/profile.svg" alt="Ic profile off">
<p class="icon-title">Login</p>
</a>
</li>
</ul>
</div>
   <?php endif; ?>
 <?php else: ?>
   
 <?php endif; ?>